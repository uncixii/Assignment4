package TF_IDF;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.PropertyConfigurator;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;


public class TF_IDF {
	public int sum = 0;
	public static class TokenizerMapper
		extends Mapper<Object, Text, Text, IntWritable>{
			private final static IntWritable one = new IntWritable(1);
			private String pattern = "[\\pP|\\pS|\\d+]";
			private Text word = new Text();
			public void map(Object key, Text value, Context context) throws
			                IOException, InterruptedException{
				String line = value.toString();
				line = line.replaceAll(pattern, "");
				FileSplit inputSplit = (FileSplit) context.getInputSplit();
                String Name = inputSplit.getPath().getName();
                String fileName = Name.substring(0, Name.lastIndexOf("."));
				StringTokenizer itr = new StringTokenizer(line);
				
				while (itr.hasMoreTokens()) {
					String W_N = (itr.nextToken()+ ">" + fileName);
					W_N = W_N.replaceAll("\\s+", "").toLowerCase();
					word.set(W_N);
					word.set(W_N);
					context.write(word,one);
				}
			}
		}
	public static class IntSumReducer
		extends Reducer<Text, IntWritable, Text, IntWritable>{
			private IntWritable result = new IntWritable();
			public void reduce(Text key, Iterable <IntWritable> values, Context
					context) throws IOException, InterruptedException{
				int sum = 0;
				for (IntWritable val : values) {
					sum += val.get();
				}
				result.set(sum);
				context.write(key, result);
		}
		
	}
	

	public static class Map2
	extends Mapper<Object, Text, Text, Text>{
		private Text DN = new Text();
		

	    private Text vall = new Text();

   		
		public void map(Object key, Text values, Context context) throws IOException, InterruptedException {
			String text = values.toString();
			String[] str = text.split("\\s+");
			StringTokenizer stk = new StringTokenizer(text);
			while(stk.hasMoreTokens()) {
				String wordF= new String();
				String[] wn = stk.nextToken().toString().split(">"); 
				wordF = wn[0]+":"+stk.nextToken(); 
				DN.set(wn[1]);
				vall.set(wordF);
                context.write(DN, vall);                				
			}			
			
}
	}

	public static class Reducer2
	extends Reducer<Text, Text, Text, Text>{
		private Text Total = new Text();
		int sumOfWordsInDocument = 0;
		String num = new String();
		String word = new String();
		private Text key = new Text();
		int sum = 0;
		int total = 0;
		
		public void reduce(Text key1, Iterable<Text> values, Context
				context) throws IOException, InterruptedException{
			List<Text> loopagain = new ArrayList<>();
			for(Text val : values) { 
				loopagain.add(new Text(val)); 
				String wc= val.toString();
				String[] wordCounter = wc.split(":");
				int count = Integer.parseInt(wordCounter[1]);
				sumOfWordsInDocument += count;
			}
			
		    for (Text line : loopagain) {
		    	String su3 = String.valueOf(sumOfWordsInDocument);
		    	String[] str2 = line.toString().split(":");
		        key.set(str2[0]+">"+key1.toString());
		        Total.set(str2[1]+":"+su3);
		        context.write(key, Total);
		    }

	}
	
}
	public static class Map3

	extends Mapper<Object, Text, Text, Text>{
        private Text one = new Text();
		String w1 = new String();
		String w2 = new String();
		private Text KEY = new Text();
		private Text Value = new Text();
		
		public void map(Object key, Text values, Context context) throws IOException, InterruptedException {
			String str = values.toString();
			
			StringTokenizer stk = new StringTokenizer(str);
			while(stk.hasMoreTokens()) {
				//split the name of document
				String[] s_L = stk.nextToken().toString().split(">");
				String word = s_L[0];
				KEY.set(word);
				String combine = s_L[1]+"<"+stk.nextToken()+">"+"1";
				Value.set(combine);
				context.write(KEY, Value);
			}
	}
}
	
	public static class Reducer3
	extends Reducer<Text, Text, Text, Text>{
		private Text key1 = new Text();
		int totalNN = 0;
		private Text value = new Text();
		public void reduce(Text key, Iterable <Text> values, Context
				context) throws IOException, InterruptedException{
			List<Text> loop2 = new ArrayList<>();
			//find the total file number that a word that exists
			for (Text val1 : values) {
				loop2.add(new Text(val1));
				String s1 = val1.toString();
				String[] s2 = s1.split(">");
				String num = s2[1];
				int a = Integer.parseInt(num);
				totalNN += a;
			}
			//reduce outcome <word filename><TF-IDF>
			for (Text val : loop2) { 
				String str1 = val.toString();
				String[] f_n = str1.split("<");
				String filename = f_n[0];
				String word = key.toString();
				String wf = word + ":" + filename;
				key1.set(wf);
				
				//find TF, Term frequency
				String[] sp2 = f_n[1].split(":");
				String tf =sp2[0];
				double tF = Integer.parseInt(tf);
				System.out.println("tF:"+ tF);
				String[] sp3 = sp2[1].split(">");
				String tnt = sp3[0];
				int tnT = Integer.parseInt(tnt);
				System.out.println("tNT:"+ tnT);
				float TF = (float)tF/(float)tnT;
				System.out.println("TF:"+ TF);
				int TND = 224;
				double IDF = Math.log((float)TND/(float)totalNN);
				
				System.out.println("IDF:"+ IDF);
				double TF_IDF = TF*IDF;
				System.out.println("TF_IDF:"+ TF_IDF);
				String TF_IDF2 = String.valueOf(TF_IDF);
				value.set(TF_IDF2);
				context.write(key1, value);
				
				
			}

			
	}
	
}	
	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("config/log4j.properties");
		Configuration conf = new Configuration();

		Job job = Job.getInstance(conf, "word3");
		job.setJarByClass(TF_IDF.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		ControlledJob ctrlJob1= new ControlledJob(conf);
		ctrlJob1.setJob(job);

		Job job2 = Job.getInstance(conf, "word3");
		job2.setJarByClass(TF_IDF.class);
		job2.setMapperClass(Map2.class);
		job2.setReducerClass(Reducer2.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job2, new Path(args[0]));
		FileOutputFormat.setOutputPath(job2, new Path(args[1]));
		ControlledJob ctrlJob2= new ControlledJob(conf);
		ctrlJob2.setJob(job2);

		Job job3 = Job.getInstance(conf, "word3");
		job3.setJarByClass(TF_IDF.class);
		job3.setMapperClass(Map3.class);
		job3.setReducerClass(Reducer3.class);
		job3.setOutputKeyClass(Text.class);
		job3.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job3, new Path(args[0]));
		FileOutputFormat.setOutputPath(job3, new Path(args[1]));
		ControlledJob ctrlJob3= new ControlledJob(conf);
		ctrlJob3.setJob(job3);
		ctrlJob2.addDependingJob(ctrlJob1);
		ctrlJob3.addDependingJob(ctrlJob2);
		JobControl jobCtrl=new JobControl("myCtrl");
		jobCtrl.addJob(ctrlJob1);
		jobCtrl.addJob(ctrlJob2);
		jobCtrl.addJob(ctrlJob3);
		
		Thread thread=new Thread(jobCtrl);
		thread.start();
		while(true) {
			if(jobCtrl.allFinished()) {
				System.out.println(jobCtrl.getSuccessfulJobList());
				jobCtrl.stop();
				break;
			}
		}
		
		System.exit(job.waitForCompletion(true) ? 0:1);
	}
	

}
